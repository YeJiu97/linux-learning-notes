# 01 - Introduction

如下图所示为Linux的系统家族树：

![Untitled](01%20-%20Introduction%20cc3a030dfe484c1a89784b62ab06eb90/Untitled.png)

一个简单的指令：du。

```java
yejiu97@DESKTOP-S9ODFEQ:/mnt/c/Users/yinia/Desktop/WSL$ du
0
```

Unix的后代：

![Untitled](01%20-%20Introduction%20cc3a030dfe484c1a89784b62ab06eb90/Untitled%201.png)

Linux的kernel：

![Untitled](01%20-%20Introduction%20cc3a030dfe484c1a89784b62ab06eb90/Untitled%202.png)

什么是Kernel：

![Untitled](01%20-%20Introduction%20cc3a030dfe484c1a89784b62ab06eb90/Untitled%203.png)