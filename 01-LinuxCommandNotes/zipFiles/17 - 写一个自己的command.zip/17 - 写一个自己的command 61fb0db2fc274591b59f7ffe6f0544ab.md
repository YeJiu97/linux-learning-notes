# 17 - 写一个自己的command

首先需要进入到bin文件夹中：

```bash
yejiu97@DESKTOP-S9ODFEQ:/$ ls
bin   dev  home  lib    lib64   media  opt   root  sbin  srv  tmp  var
boot  etc  init  lib32  libx32  mnt    proc  run   snap  sys  usr
yejiu97@DESKTOP-S9ODFEQ:/$ cd usr
yejiu97@DESKTOP-S9ODFEQ:/usr$ ls
bin  games  include  lib  lib32  lib64  libexec  libx32  local  sbin  share  src
yejiu97@DESKTOP-S9ODFEQ:/usr$ cd local
yejiu97@DESKTOP-S9ODFEQ:/usr/local$ ls
bin  etc  games  include  lib  man  sbin  share  src
yejiu97@DESKTOP-S9ODFEQ:/usr/local$ ls
bin  etc  games  include  lib  man  sbin  share  src
yejiu97@DESKTOP-S9ODFEQ:/usr/local$ cd bin
yejiu97@DESKTOP-S9ODFEQ:/usr/local/bin$ ls
yejiu97@DESKTOP-S9ODFEQ:/usr/local/bin$
```

![Untitled](17%20-%20%E5%86%99%E4%B8%80%E4%B8%AA%E8%87%AA%E5%B7%B1%E7%9A%84command%2061fb0db2fc274591b59f7ffe6f0544ab/Untitled.png)